<!-- <?php

// class Koneksi {
//     // Properti kelas
//     private $server = "localhost";
//     private $username = "root";
//     private $password = "";
//     private $db = "ujikom_todolist";
//     public $koneksi;

//     // Konstruktor kelas
//     public function __construct() {
//         $this->koneksi = new mysqli($this->server, $this->username, $this->password, $this->db);

//         // Mengecek koneksi
//         if ($this->koneksi->connect_error) {
//             die("Koneksi database gagal: " . $this->koneksi->connect_error);
//         } else {
//             echo "Koneksi ke database " . $this->db . " berhasil";
//         }
//     }
// }

// // Membuat objek koneksi
// $koneksi = new Koneksi();

?> -->
